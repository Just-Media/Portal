<?php header("Location: http://msdb.dyndns.org/msdb/1.1/main.php?msdbUSER=msdbUser&msdbPW=msdbPasswd&msdbDB=msdbDemo&msdbTNAME=dtmovies"); exit; ?>
