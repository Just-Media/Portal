<?php
/************************************************************/



$rcsid='$Id: library.php,v 1.5 2004/08/21 12:38:27 engine Exp engine $ ';
$copyRight="Copyright (c) Ohad Aloni 1990-2004. All rights reserved.";
$licenseId="Released under http://ohad.dyndns.org/license.txt (BSD)";
/************************************************************/
require_once("msdbConfig.php");
require_once("msdbMoreConfig.php");
require_once("globals.php");
/******************************/
require_once("aliases.php");
require_once("compat.php");
require_once("util.php");
require_once("jsutils.php");
require_once("msDb.php");
require_once("date.php");
require_once("file.php");
require_once("slike.php");
require_once("url.php");
require_once("meta.php");
/************************************************************/
?>
