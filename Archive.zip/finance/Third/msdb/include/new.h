<FORM NAME=newForm>

<INPUT TYPE=hidden NAME="msdb_t0" value="$msdb_t0">
<INPUT TYPE=hidden NAME="msdbDB" value="$msdbDB">
<INPUT TYPE=hidden NAME="msdbTNAME" value="$msdbTNAME">
<INPUT TYPE=hidden NAME="msdbSID" value="$msdbSID">
<INPUT TYPE=hidden NAME="msdbSIDST" value="$msdbSIDST">
<INPUT type=hidden name="msdbEA" value="msdbInsert">

	<TR class=msdbNew>
