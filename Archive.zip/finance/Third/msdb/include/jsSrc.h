
<LINK REL="SHORTCUT ICON" href="$iconDir/favicon.ico"></LINK>

<LINK REL="STYLESHEET" TYPE="text/css" HREF="$jsDir/styles.css"></LINK>
<LINK REL="STYLESHEET" TYPE="text/css" HREF="$jsDir/dialogstyle.css"></LINK>

<SCRIPT LANGUAGE="JavaScript" SRC="$jsDir/msdb.js"></SCRIPT>
<SCRIPT LANGUAGE="JavaScript" SRC="$jsDir/dialog.js"></SCRIPT>

<SCRIPT LANGUAGE="javascript">
	var msdbTop = new msdb('$msdbMyHomeUrl', '$msdbDB', '$msdbTNAME', $msdbSID, $msdbSIDST, '$msdbPkName') ;
</SCRIPT>
