<TABLE BORDER=1 CLASS=listDBs>
<TR CLASS=listDBs>
	<TD>Database Name</TD>
	<TD>Tables</TD>
</TR>
