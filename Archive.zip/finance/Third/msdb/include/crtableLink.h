	<BR>
	<A  HREF="?msdbSID=$msdbSID&msdbSIDST=$msdbSIDST&msdbDB=$msdbDB&msdbTNAME=$msdbTNAME&msdbEA=msdbGenCrtable">$msdbTNAME.crtable</A>
	<BR>
