<BR>
<TABLE BORDER="0">
<FORM METHOD=POST>
<INPUT TYPE=hidden NAME="msdb_t0" value="$msdb_t0">
<TR>
	<TD>User</TD>
	<TD><INPUT TYPE=text NAME="msdbUSER" value="$msdbUSER"></TD>
</TR><TR>
	<TD>Password</TD>
	<TD><INPUT TYPE=password NAME="msdbPW"></TD>
</TR><TR>
	<TD COLSPAN=2><INPUT TYPE=submit VALUE=Login></TD>
</TR>
</FORM>
</TABLE>

