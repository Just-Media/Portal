<FONT face="helvetica">
<CENTER>
	My SQL Data Browser Version $msdbVersion<BR>

	<A HREF="http://www.engine.com/msdb/">Home</A>
	<A HREF="http://sourceforge.net/projects/msdb/">Download</A>
	<A HREF="Help/">Help</A>
	<A HREF="Help/about.txt">About</A>
	<BR>
	<A  HREF="javascript:msdbCmd('msdbSelectDB', '')" TARGET=_top>Databases</A>
	<A  HREF="javascript:msdbCmd('msdbSelectTable', '')">Tables</A>
	<A  HREF="javascript:msdbCmd('msdbLogout','')">Logout</A>

</CENTER>
</FONT>

