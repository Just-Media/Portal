<BR>
<TABLE BORDER=0 cellpadding=2 cellspacing=2 CLASS=msdbPerf>
<TR><TD COLSPAN=3>perf data</TD></TR>
<TR><TD>File</TD><TD>Microsecs ELAPSED</TD></TR>
