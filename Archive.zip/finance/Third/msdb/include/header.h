
<A  HREF="?msdbSID=$msdbSID&msdbSIDST=$msdbSIDST" TARGET=_top><IMG alt ="Home" src="$iconDir/r22icon.gif" border=0 ></A><BR>

<IMG SRC="$iconDir/hr-island.gif"><BR>
<!-- <FONT face="helvetica">Its $DATE on the server</FONT><BR> -->
