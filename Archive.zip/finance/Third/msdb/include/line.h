<TR class=$lineClass><TD>$lineNumber</TD>
