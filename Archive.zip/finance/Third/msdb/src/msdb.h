#define MSDB_ERROR(m) msdbError(__FILE__.": ".__LINE__.": ".(m))
#define MSDB_PERF(c) msdbPerf(__FILE__, __LINE__, (c))
