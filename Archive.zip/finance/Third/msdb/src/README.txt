This is not the install folder
------------------------------
This folder named 'src' contains files that are subject
to preprocessing under LINUX with 'cpp -P -C' during development.
This is not the main installation folder.
The folder you are looking for as the installation
folder is one level up from here.
This folder is supplied as part of the release for
development oriented  documentation.
If you try to run from this folder things will not work at
all and errors regrading undefined functions will be reported
by php.
