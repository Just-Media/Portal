<TR class=cbHead>
	<TD> Date </TD>
	<TD> Amount </TD>
	<TD> Paid To/From </TD>
	<TD> Category </TD>
	<TD> Notes </TD>
	<TD ALIGN=LEFT> Balance </TD>
	<TD COLSPAN=4></TD>
</TR>
