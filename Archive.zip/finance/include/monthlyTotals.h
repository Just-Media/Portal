<TR class=$cbLineClass>
	<TD> $sEndDate </TD>
	<TD ALIGN=RIGHT> $amount </TD>
</TR>
