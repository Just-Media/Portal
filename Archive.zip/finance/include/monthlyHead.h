<TR class=cbHead>
	<TD> Category </TD>
	<TD> Amount </TD>
</TR>
