<TR class=$cbLineClass>
	<TD> <A HREF="javascript:cbRestrictView(0, '$category');">$category</A> </TD>
	<TD ALIGN=RIGHT $negAmountClass> $amount </TD>
</TR>
