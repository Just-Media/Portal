<TR>
	<TD class=$restrictClass><A HREF="javascript:cbRestrictView($which, '$fval');">**</A></TD>
	<TD class=$fvalClass><A HREF="javascript:cbSet($which, '$fval');">$fval</A></TD>
	<TD ALIGN=RIGHT class=$totalClass>$Total</TD>
</TR>
