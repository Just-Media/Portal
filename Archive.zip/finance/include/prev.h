<TR class=cbPrev>
	<TD COLSPAN="5">Previous balance as of <B>$prevDate</B></TD>
	<TD class=$prevBalClass ALIGN=RIGHT>$prevBal</TD>
	<TD COLSPAN="4">
		(<A HREF="javascript:cbCmd('cbUncons', 0, '')">Unfold</A>)
	</TD>
</TR>
