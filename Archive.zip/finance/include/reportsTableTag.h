<BR>
<TABLE class=cbReportsTable BORDER=0 CELLPADDING=2 CELLSPACING=2>
<TR>
	<TD COLSPAN=2 class=cbReportsTitle>Summaries</TD>
	<TD COLSPAN=1 class=cbReportsTitle><A HREF="javascript:cbMonthly()">Month by Month</A></TD>
</TR>
