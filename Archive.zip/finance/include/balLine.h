<TR>
	<TD class=$restrictClass><A HREF="javascript:cbRestrictView($which, '$cdate');">**</A></TD>
	<TD class=$fvalClass>$fval</TD>
	<TD ALIGN=RIGHT class=$totalClass>$Total</TD>
</TR>
